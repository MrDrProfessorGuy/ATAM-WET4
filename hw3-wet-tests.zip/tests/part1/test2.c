#include<stdio.h>

int main() {
	printf("Haalifut hazra habaita el hacarmel");
	return 0;
}