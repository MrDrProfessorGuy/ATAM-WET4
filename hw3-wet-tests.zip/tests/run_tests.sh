#!/bin/bash

echo "Start testing..."
mkdir hw3-wet
unzip -qq hw3-wet.zip -d hw3-wet
cd hw3-wet
echo "Part 1:"
cd part1
printf "\tDownloading binutils...\n"
wget http://ftp.gnu.org/gnu/binutils/binutils-2.36.1.tar.xz -q -O - | tar -xJ &>/dev/null
cd binutils-2.36.1
printf "\tCompiling binutils...\n"
./configure &>/dev/null
make &>/dev/null
if [ -f "../readelf.c" ]; then	
	cp ../readelf.c ./binutils/readelf.c
	printf "\tCompiling readelf with your file...\n"
	make &>/dev/null
	if [ $? -eq 0 ]; then
		cd binutils
		if [ -f "readelf" ]; then
			#TEST 1
			./readelf -s ../../../../part1/test1.o > ../../../../part1/res 2>/dev/null
			if [ $? -eq 0 ]; then
				diff "../../../../part1/res" "../../../../part1/out1" &>/dev/null
				if [ $? -eq 0 ]; then
					echo -e "\tTest 1:\tPASS"
				else
					echo -e "\tTest 1:\tFAIL - diff"
				fi
			else
				echo -e "\tTest 1:\tFAIL - runtime error"
			fi

			#TEST 2
			./readelf -S ../../../../part1/test1.o > ../../../../part1/res 2>/dev/null
			if [ $? -eq 0 ]; then
				diff "../../../../part1/res" "../../../../part1/out2" &>/dev/null
				if [ $? -eq 0 ]; then
					echo -e "\tTest 2:\tPASS"
				else
					echo -e "\tTest 2:\tFAIL - diff"
				fi
			else
				echo -e "\tTest 2:\tFAIL - runtime error"
			fi

			#TEST 3
			./readelf -l ../../../../part1/test1.out > ../../../../part1/res 2>/dev/null
			if [ $? -eq 0 ]; then
				diff "../../../../part1/res" "../../../../part1/out3" &>/dev/null
				if [ $? -eq 0 ]; then
					echo -e "\tTest 3:\tPASS"
				else
					echo -e "\tTest 3:\tFAIL - diff"
				fi
			else
				echo -e "\tTest 3:\tFAIL - runtime error"
			fi

			#TEST 4
			./readelf -S ../../../../part1/test2.out > ../../../../part1/res 2>/dev/null
			if [ $? -eq 0 ]; then
				diff "../../../../part1/res" "../../../../part1/out4" &>/dev/null
				if [ $? -eq 0 ]; then
					echo -e "\tTest 4:\tPASS"
				else
					echo -e "\tTest 4:\tFAIL - diff"
				fi
			else
				echo -e "\tTest 4:\tFAIL - runtime error"
			fi

			#TEST 5
			./readelf -s ../../../../part1/test3.o > ../../../../part1/res 2>/dev/null
			if [ $? -eq 0 ]; then
				diff "../../../../part1/res" "../../../../part1/out5" &>/dev/null
				if [ $? -eq 0 ]; then
					echo -e "\tTest 5:\tPASS"
				else
					echo -e "\tTest 5:\tFAIL - diff"
				fi
			else
				echo -e "\tTest 5:\tFAIL - runtime error"
			fi

			#TEST 6
			./readelf -s ../../../../part1/test4.o > ../../../../part1/res 2>/dev/null
			if [ $? -eq 0 ]; then
				diff "../../../../part1/res" "../../../../part1/out6" &>/dev/null
				if [ $? -eq 0 ]; then
					echo -e "\tTest 6:\tPASS"
				else
					echo -e "\tTest 6:\tFAIL - diff"
				fi
			else
				echo -e "\tTest 6:\tFAIL - runtime error"
			fi

			#TEST 7
			./readelf -SW ../../../../part1/test2.out > ../../../../part1/res 2>/dev/null
			if [ $? -eq 0 ]; then
				diff "../../../../part1/res" "../../../../part1/out7" &>/dev/null
				if [ $? -eq 0 ]; then
					echo -e "\tTest 7:\tPASS"
				else
					echo -e "\tTest 7:\tFAIL - diff"
				fi
			else
				echo -e "\tTest 7:\tFAIL - runtime error"
			fi

			#TEST 8
			./readelf -aW ../../../../part1/test2.out > ../../../../part1/res 2>/dev/null
			if [ $? -eq 0 ]; then
				diff "../../../../part1/res" "../../../../part1/out8" &>/dev/null
				if [ $? -eq 0 ]; then
					echo -e "\tTest 8:\tPASS"
				else
					echo -e "\tTest 8:\tFAIL - diff"
				fi
			else
				echo -e "\tTest 8:\tFAIL - runtime error"
			fi

			rm readelf ../../../../res &>/dev/null
		else
			echo -e "\tFAIL- make error"
		fi
	else
		echo -e "\tFAIL- make error"
	fi
	sudo rm readelf.c
	cd ../
	make clean &>/dev/null
else
	echo -e "\tFAIL- cannot find readelf.c file"
fi


cd ../../part2
printf "\n\nPart 2:\n"

if [ -f "hw3_hook.asm" ]; then
	if [ -f "hw3.ld" ]; then
		as -W -q hw3_hook.asm -o hw3_hook.o &>/dev/null
		if [ $? -eq 0 ]; then
			#TEST 1
			sudo cp "../../part2/a.o" "./a.o"
			sudo cp "../../part2/b.o" "./b.o"
			sudo cp "../../part2/out1" "out"
			ld a.o b.o hw3_hook.o -o hw3.out -T hw3.ld &>/dev/null
			if [ $? -eq 0 ]; then
				timeout 120s ./hw3.out > res 2>/dev/null
				if [ $? -eq 0 ]; then
					diff "res" "out" &>/dev/null
					if [ $? -eq 0 ]; then
						echo -e "\tTest 1:\tPASS"
					else
						echo -e "\tTest 1:\tFAIL - diff"
					fi
				else
					echo -e "\tTest 1:\tFAIL - runtime error"
				fi
			else
				echo -e "\tTest 1:\tFAIL - ld error"
			fi

			#TEST 2
			sudo cp "../../part2/a.o" "./a.o"
			sudo cp "../../part2/b.o" "./b.o"
			sudo cp "../../part2/out2" "out"
			ld hw3_hook.o b.o a.o -o hw3.out -T hw3.ld &>/dev/null
			if [ $? -eq 0 ]; then
				timeout 120s ./hw3.out > res 2>/dev/null
				if [ $? -eq 0 ]; then
					diff "res" "out" &>/dev/null
					if [ $? -eq 0 ]; then
						echo -e "\tTest 2:\tPASS"
					else
						echo -e "\tTest 2:\tFAIL - diff"
					fi
				else
					echo -e "\tTest 2:\tFAIL - runtime error"
				fi
			else
				echo -e "\tTest 2:\tFAIL - ld error"
			fi
			
			#TEST 3
			sudo cp "../../part2/a.o" "./a.o"
			sudo cp "../../part2/b2.o" "./b.o"
			sudo cp "../../part2/c.o" "./c.o"
			sudo cp "../../part2/out3" "out"
			ld c.o hw3_hook.o b.o a.o -o hw3.out -T hw3.ld &>/dev/null
			if [ $? -eq 0 ]; then
				timeout 120s ./hw3.out > res 2>/dev/null
				if [ $? -eq 0 ]; then
					diff "res" "out" &>/dev/null
					if [ $? -eq 0 ]; then
						echo -e "\tTest 3:\tPASS"
					else
						echo -e "\tTest 3:\tFAIL - diff"
					fi
				else
					echo -e "\tTest 3:\tFAIL - runtime error"
				fi
			else
				echo -e "\tTest 3:\tFAIL - ld error"
			fi

			#TEST 4
			sudo cp "../../part2/a.o" "./a.o"
			sudo cp "../../part2/b3.o" "./b.o"
			sudo cp "../../part2/c.o" "./c.o"
			sudo cp "../../part2/out4" "out"
			ld b.o c.o hw3_hook.o a.o -o hw3.out -T hw3.ld &>/dev/null
			if [ $? -eq 0 ]; then
				timeout 120s ./hw3.out > res 2>/dev/null
				if [ $? -eq 0 ]; then
					diff "res" "out" &>/dev/null
					if [ $? -eq 0 ]; then
						echo -e "\tTest 4:\tPASS"
					else
						echo -e "\tTest 4:\tFAIL - diff"
					fi
				else
					echo -e "\tTest 4:\tFAIL - runtime error"
				fi
			else
				echo -e "\tTest 4:\tFAIL - ld error"
			fi

			#TEST 5
			sudo cp "../../part2/a.o" "./a.o"
			sudo cp "../../part2/b4.o" "./b.o"
			sudo cp "../../part2/out5" "out"
			ld hw3_hook.o b.o a.o -o hw3.out -T hw3.ld &>/dev/null
			if [ $? -eq 0 ]; then
				timeout 120s ./hw3.out > res 2>/dev/null
				if [ $? -eq 0 ]; then
					diff "res" "out" &>/dev/null
					if [ $? -eq 0 ]; then
						echo -e "\tTest 5:\tPASS"
					else
						echo -e "\tTest 5:\tFAIL - diff"
					fi
				else
					echo -e "\tTest 5:\tFAIL - runtime error"
				fi
			else
				echo -e "\tTest 5:\tFAIL - ld error"
			fi

		else
			echo -e "\tFAIL- as error"
		fi
	else
		echo -e "\tFAIL- cannot find hw3.ld file"
	fi
else
	echo -e "\tFAIL- cannot find hw3_hook.asm file"
fi

cd ../../
sudo rm hw3-wet -rf
echo "END OF TEST"
